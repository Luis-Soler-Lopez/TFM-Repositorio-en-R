setwd("/home/luis/Documentos/TFM/ED0_1/Mapping y AED")
getwd()
