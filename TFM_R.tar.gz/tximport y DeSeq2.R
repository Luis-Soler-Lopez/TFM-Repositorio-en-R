##IMPORTAR DATOS CON TXIMPORT
#Activar packages de tximport,readr y DESeq2.

library(tximport)
library(readr)
library(DESeq2)

#Comprobar en directorio de trabajo y seleccionar el que nos convenga.

setwd()# Aqui va la ruta hacia la carpeta ente barra "/".
dir<-getwd()
dir

#Se crea un archivo .txt con el nombre de los genes a analizar.
#Lo cargo y lo leo.

nombresgenes<-read.table("nombresgenes.txt", header = TRUE)

# Duplico el nombre de los genes en dos columnas (Requerimiento de tximport para Kallisto)

nombresgenes<-cbind(nombresgenes, nombresgenes[,1])

# Nombro las dos columnas 

colnames(nombresgenes)<-c("geneID", "transcriptID")
head(nombresgenes)

# Creo la tabla de datos sin nombres o numeración en las filas.

write.table(nombresgenes, file = "nombreGenTranscrito.txt", sep="\t", quote = FALSE, row.names= FALSE)

# Ceo un archivo para tximport con el nombre de las muestras y el tipo o condiciónn de estas (separadas por tabulación).
#Esto se hace para crear el archivo tximport leyendo las carpetas donde previamente situamos los archivo abundance.h5.
# Cargamos la tabla con los nombres con read.table(),con "header=TRUE" para que use la cabecera del documento directamente como nombre de las columnas.

muestras<-read.table("muestras.txt", header=TRUE)
muestras

# Se crea una ruta de archivos y leemos una tabla que enlace trasncritos a los genes para generar un data set.

archivos <- file.path(dir,"kallisto",samples$muestra, "abundance.h5")
archivos
tx2gene<-read.table("nombreGenTranscrito.txt",header=TRUE)
head(tx2gene)
txi <- tximport(archivos, type="kallisto", tx2gene=tx2gene,countsFromAbundance = "no" )#countsFromAbundance no porque ya hace el conteo DeSeq2.
head(txi)

#Ya he introducido los archivos abunddance.h5 como objetos para hacer un data set.
#Ahora marcamos las condiciones a las muestras.

coldata<- data.frame(condition = factor(rep(c("rojo","verde"),each =3)))
#Los vectores "rojo" y "verde" son transformados a un factor que se toma como tipos de condici�n de las muestras, con 3 repeticiones porque son 3 muestras de cada condicion. .

#Fijamos el nombre de las filas y columnas de los datos de condicion y de muestra como objetos y asi los asociamos y ordenamos.

rownames(coldata) <- colnames(txi$counts)

#Creamos el data set para DeSeq2 a partir del objeto txi y la informacion de la tabla ya ordenada.

ddsTxi <- DESeqDataSetFromTximport(txi, colData=coldata, design = ~condition)

##ANALISIS CON DeSeq2
#Pre-filtering

#Elimino las filas en las que hay muy pocas lecturas, reduzco el tama�o de la memoria del obejto dds y aumento la velocidad de las funciones de transformaci�n y prueba dentro de DESeq.
#Marc� el numero prefiltrado de lecturas m�nimas(este caso 30)

ddsTxi<-ddsTxi[rowSums(counts(ddsTxi))>30]

ddsTxi$condition

#ANALISIS CON DESEQ2 Y EXTRACCION DE RESULTADOS..

DeSeq2<-DESeq(ddsTxi)
res<-results(DeSeq2)
#head(res) para comprobar que estan los datos.
#mcols(res)$description describe los campos de los datos.

#Escribo los resultados.
write.table(res, file = "DESeq2_Rojo_vs_Verde.lista", quote = FALSE, dec = ".", sep = "\t" ) 

#Analizo los genes con mayor expresi�n seg�n p-value y logfoldchange de los resultados.

genes_UP<-res[which(res$padj<0.01&res$log2FoldChange>1)]

#Escribo los resultados.
write.table(genes_UP, file = "Genes_UP.lista", quote = FALSE, dec = ",", sep = "\t" )

#Analizo los genes con menor expresi�n seg�n p-value y logfoldchange de los resultados.

genes_DOWN<-res[which(res$padj<0.01&res$log2FoldChange< -1)]

#Escribo los resultados.
write.table(genes_DOWN, file = "Genes_DOWN.lista", quote = FALSE, dec = ",", sep = "\t" )

##ANALISIS DE MA PLOTS
plotMA(res, ylim=c(-3,3))#Crea el grafico MA.

idx <- identify(res$baseMean, res$log2FoldChange)#Permite identificar puntos seleccionados en la grafica.
rownames(res)[idx]#Da los nombre de los genes marcados.

#ANALISIS PCA PLOTS
DeSeqTrans<-rlog(DeSeq2, blind = TRUE)
datosPCA<-plotPCA(DeSeqTrans,intgroup = "condition",ntop=100000,returnData = FALSE)
datosPCA
